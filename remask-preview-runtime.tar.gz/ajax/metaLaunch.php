<?php
require_once __DIR__ . '/../settings.php';
require_once __DIR__ . '/../checkpassword.php';
require_once __DIR__ . '/../classes/MetaEndpoint.php';

$tempFile = null;
try {
    $profile = trim((string)($_POST['profile'] ?? ''));
    $accountId = trim((string)($_POST['account_id'] ?? ''));
    $payloadRaw = (string)($_POST['payload'] ?? '');
    if ($profile === '') throw new InvalidArgumentException('profile is required');
    if ($accountId === '') throw new InvalidArgumentException('account_id is required');
    if ($payloadRaw === '') throw new InvalidArgumentException('payload is required');

    $payload = json_decode($payloadRaw, true, 512, JSON_THROW_ON_ERROR);
    if (!is_array($payload)) throw new InvalidArgumentException('payload must be a JSON object');

    if (!isset($_FILES['media']) || !is_array($_FILES['media'])) {
        throw new InvalidArgumentException('media file is required');
    }
    $upload = $_FILES['media'];
    if (($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Media upload failed with PHP code ' . (int)($upload['error'] ?? -1));
    }
    $tempFile = (string)$upload['tmp_name'];
    if (!is_uploaded_file($tempFile) && !is_file($tempFile)) {
        throw new RuntimeException('Uploaded media temporary file is unavailable.');
    }

    $mime = function_exists('mime_content_type') ? (mime_content_type($tempFile) ?: '') : '';
    $mediaType = str_starts_with($mime, 'video/') ? 'video' : (str_starts_with($mime, 'image/') ? 'image' : '');
    if ($mediaType === '') {
        throw new InvalidArgumentException("Unsupported media MIME type: {$mime}");
    }

    // First implementation is intentionally PAUSED-only to prevent accidental spend
    // while the new engine is being validated account-by-account.
    $payload['campaign']['status'] = 'PAUSED';
    $payload['adset']['status'] = 'PAUSED';
    $payload['ad']['status'] = 'PAUSED';

    $review = MetaEndpoint::reviewLaunch($profile, [$accountId], $payload, [], false);
    if (empty($review['ready'])) {
        $row = (array)($review['accounts'][0] ?? []);
        throw new InvalidArgumentException('Launch Review failed: ' . implode('; ', (array)($row['errors'] ?? [])));
    }

    $service = MetaEndpoint::serviceForAccountName($profile);
    $result = $service->launch($accountId, $payload, $tempFile, $mediaType);
    MetaEndpoint::ok($result);
} catch (Throwable $e) {
    MetaEndpoint::fail($e);
}
