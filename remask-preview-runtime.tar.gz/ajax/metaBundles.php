<?php
require_once __DIR__ . '/../settings.php';
require_once __DIR__ . '/../checkpassword.php';
require_once __DIR__ . '/../classes/MetaEndpoint.php';

try {
    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    $store = MetaEndpoint::bundleStore();
    if ($method === 'GET') {
        MetaEndpoint::ok(['bundles' => $store->list()]);
    }

    $input = MetaEndpoint::input();
    $action = strtolower(trim((string)($input['action'] ?? 'save')));
    if ($action === 'delete') {
        $deleted = $store->delete((string)($input['id'] ?? ''));
        MetaEndpoint::ok(['deleted' => $deleted, 'bundles' => $store->list()]);
    }

    $dataRaw = $input['data'] ?? null;
    if (is_string($dataRaw)) $dataRaw = json_decode($dataRaw, true, 512, JSON_THROW_ON_ERROR);
    if (!is_array($dataRaw)) throw new InvalidArgumentException('Bundle data must be a JSON object.');
    $saved = $store->save(
        isset($input['id']) && trim((string)$input['id']) !== '' ? (string)$input['id'] : null,
        (string)($input['name'] ?? ''),
        $dataRaw
    );
    MetaEndpoint::ok(['bundle' => $saved, 'bundles' => $store->list()]);
} catch (Throwable $e) {
    MetaEndpoint::fail($e);
}
