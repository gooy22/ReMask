<?php
require_once __DIR__ . '/../settings.php';
require_once __DIR__ . '/../checkpassword.php';
require_once __DIR__ . '/../classes/MetaEndpoint.php';
try {
    $input = MetaEndpoint::input();
    $jobId = trim((string)($input['job_id'] ?? ''));
    if ($jobId === '') throw new InvalidArgumentException('job_id is required');
    MetaEndpoint::ok(MetaEndpoint::jobStore()->forceRetryReviewRequired($jobId));
} catch (Throwable $e) {
    MetaEndpoint::fail($e);
}
