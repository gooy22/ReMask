<?php
require_once __DIR__ . '/../settings.php';
require_once __DIR__ . '/../checkpassword.php';
require_once __DIR__ . '/../classes/MetaEndpoint.php';
require_once __DIR__ . '/../classes/StorageHealth.php';
try {
    MetaEndpoint::ok(StorageHealth::inspect());
} catch (Throwable $e) {
    MetaEndpoint::fail($e);
}
