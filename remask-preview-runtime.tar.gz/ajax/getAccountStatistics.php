<?php
require_once __DIR__ . '/../settings.php';
require_once __DIR__ . '/../checkpassword.php';
require_once __DIR__ . '/../classes/MetaEndpoint.php';
require_once __DIR__ . '/../classes/MetaStatisticsService.php';

try {
    $profile = trim((string)($_GET['acc_name'] ?? ''));
    if ($profile === '') throw new InvalidArgumentException('acc_name is required');
    $datePreset = trim((string)($_GET['datetime'] ?? 'today'));

    $service = MetaEndpoint::serviceForAccountName($profile);
    $statistics = new MetaStatisticsService($service);
    $preflight = MetaEndpoint::cachedPreflight($profile, false);
    $accountSummaries = is_array($preflight['ad_accounts']['data'] ?? null) ? $preflight['ad_accounts']['data'] : null;

    // Keep the historical response shape used by scripts/requests.js.
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    $payload = $statistics->getProfileStatistics($datePreset, $accountSummaries);
    $payload['meta']['account_list_cache'] = $preflight['_cache'] ?? null;
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
} catch (Throwable $error) {
    MetaEndpoint::fail($error);
}
