<?php
require_once __DIR__ . '/../settings.php';
require_once __DIR__ . '/../checkpassword.php';
require_once __DIR__ . '/../classes/RemaskProxy.php';
require_once __DIR__ . '/../classes/FbAccount.php';
require_once __DIR__ . '/../classes/AccountStoreFactory.php';
require_once __DIR__ . '/../classes/ResponseFormatter.php';

try {
    $name = trim((string)($_POST['name'] ?? ''));
    if ($name === '') throw new InvalidArgumentException('Name is required.');
    $serializer = AccountStoreFactory::create(ACCOUNTSFILENAME);
    $existing = $serializer->getAccountByName($name);

    $tokenInput = trim((string)($_POST['token'] ?? ''));
    $token = $tokenInput !== '' ? $tokenInput : (string)($existing?->token ?? '');
    if ($token === '') throw new InvalidArgumentException('Token is required for a new profile.');

    $cookiesInput = trim((string)($_POST['cookies'] ?? ''));
    if ($cookiesInput === '' && $existing !== null) {
        $cookies = json_encode($existing->cookies, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
        $dtsg = $existing->dtsg;
    } else {
        $cookies = $cookiesInput !== '' ? $cookiesInput : '[]';
        $dtsg = null;
    }

    $clearProxy = filter_var($_POST['clear_proxy'] ?? false, FILTER_VALIDATE_BOOLEAN);
    $proxyInput = trim((string)($_POST['proxy'] ?? ''));
    if ($clearProxy) {
        $proxy = null;
    } elseif ($proxyInput === '' && $existing !== null) {
        $proxy = $existing->proxy;
    } else {
        $proxy = RemaskProxy::fromSemicolonString($proxyInput);
    }

    $newAcc = new FbAccount($name, $token, $cookies, $dtsg, $proxy);
    $serializer->addOrUpdateAccount($newAcc);
    ResponseFormatter::Respond(['res' => json_encode([
        'name' => $newAcc->name,
        'legacy_ready' => $newAcc->isLegacyReady(),
        'proxy_configured' => $newAcc->proxy !== null,
        'credentials_preserved' => $existing !== null && $tokenInput === '',
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)]);
} catch (Throwable $e) {
    ResponseFormatter::Respond(['error' => $e->getMessage()]);
}
