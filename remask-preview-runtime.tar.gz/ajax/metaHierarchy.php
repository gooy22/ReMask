<?php
require_once __DIR__ . '/../settings.php';
require_once __DIR__ . '/../checkpassword.php';
require_once __DIR__ . '/../classes/MetaEndpoint.php';
require_once __DIR__ . '/../classes/AccountStoreFactory.php';
require_once __DIR__ . '/../classes/FbAccount.php';
require_once __DIR__ . '/../classes/RemaskProxy.php';
require_once __DIR__ . '/../classes/WorkspaceMetaStore.php';
require_once __DIR__ . '/../classes/PostgresWorkspaceMetaStore.php';
require_once __DIR__ . '/../classes/Database.php';
require_once __DIR__ . '/../classes/ActivityLogFactory.php';
require_once __DIR__ . '/../classes/ProxyHealthService.php';

function hierarchy_activity(array $event): void
{
    try { ActivityLogFactory::create()->append($event); } catch (Throwable $ignored) { /* history must never break the action */ }
}

function hierarchy_workspace_meta_store(): object
{
    if (defined('REMASK_WORKSPACE_META_STORE') && REMASK_WORKSPACE_META_STORE === 'postgres') {
        return new PostgresWorkspaceMetaStore(Database::connection());
    }
    return new WorkspaceMetaStore(REMASK_WORKSPACE_META_FILE);
}

function hierarchy_profile_snapshot(string $profile, ?array $workspaceMeta = null): array
{
    if ($workspaceMeta === null) $workspaceMeta = hierarchy_workspace_meta_store()->all();
    $profileMeta = is_array($workspaceMeta[$profile] ?? null) ? $workspaceMeta[$profile] : [];
    $store = AccountStoreFactory::create(ACCOUNTSFILENAME);
    $account = $store->getAccountByName($profile);
    if ($account === null) throw new InvalidArgumentException("ReMask profile not found: {$profile}");

    $preflight = MetaEndpoint::peekCachedPreflight($profile);
    $businesses = MetaEndpoint::peekCachedAsset($profile, 'businesses', '');
    $businessRows = is_array($businesses['data'] ?? null) ? $businesses['data'] : [];
    $allAccounts = is_array($preflight['ad_accounts']['data'] ?? null) ? $preflight['ad_accounts']['data'] : [];

    $businessAccountMap = [];
    $bmRows = [];
    foreach ($businessRows as $business) {
        if (!is_array($business)) continue;
        $businessId = (string)($business['id'] ?? '');
        if ($businessId === '') continue;
        $cachedAccounts = MetaEndpoint::peekCachedAsset($profile, 'business_ad_accounts', $businessId);
        $owned = is_array($cachedAccounts['data'] ?? null) ? $cachedAccounts['data'] : [];
        foreach ($owned as $rk) {
            if (!is_array($rk)) continue;
            $rkId = (string)($rk['id'] ?? '');
            if ($rkId !== '') $businessAccountMap[$rkId] = ['id' => $businessId, 'name' => (string)($business['name'] ?? $businessId)];
        }
        $bmRows[] = [
            'profile' => $profile,
            'group' => (string)($profileMeta['group'] ?? ''),
            'id' => $businessId,
            'name' => (string)($business['name'] ?? $businessId),
            'verification_status' => (string)($business['verification_status'] ?? ''),
            'timezone_id' => $business['timezone_id'] ?? null,
            'vertical' => (string)($business['vertical'] ?? ''),
            'primary_page' => $business['primary_page'] ?? null,
            'ad_account_count' => count($owned),
            'accounts' => $owned,
            'cache' => $cachedAccounts['_cache'] ?? null,
        ];
    }

    $rkRows = [];
    foreach ($allAccounts as $rk) {
        if (!is_array($rk)) continue;
        $id = (string)($rk['id'] ?? '');
        if ($id === '') continue;
        $bm = $businessAccountMap[$id] ?? null;
        $rk['profile'] = $profile;
        $rk['group'] = (string)($profileMeta['group'] ?? '');
        $rk['business_id'] = $bm['id'] ?? '';
        $rk['funding'] = MetaEndpoint::peekCachedAsset($profile, 'funding', $id);
        $rk['business_name'] = $bm['name'] ?? (string)($rk['business_name'] ?? '');
        $rkRows[] = $rk;
    }

    $proxy = $account->proxy;
    return [
        'profile' => [
            'name' => $profile,
            'group' => (string)($profileMeta['group'] ?? ''),
            'user_id' => (string)($preflight['identity']['id'] ?? $account->userId ?? ''),
            'facebook_name' => (string)($preflight['identity']['name'] ?? ''),
            'synced' => $preflight !== null,
            'permissions' => $preflight['permissions'] ?? [],
            'ads_management_granted' => (bool)($preflight['ads_management_granted'] ?? false),
            'business_management_granted' => (bool)($preflight['business_management_granted'] ?? false),
            'proxy_configured' => $proxy !== null,
            'proxy' => $proxy ? [
                'type' => $proxy->type,
                'ip' => $proxy->ip,
                'port' => $proxy->port,
            ] : null,
            'proxy_health' => is_array($profileMeta['proxy_health'] ?? null) ? $profileMeta['proxy_health'] : null,
            'legacy_ready' => $account->isLegacyReady(),
            'bm_count' => count($bmRows),
            'rk_count' => count($rkRows),
            'cache' => $preflight['_cache'] ?? null,
        ],
        'businesses' => $bmRows,
        'ad_accounts' => $rkRows,
    ];
}

function hierarchy_inventory(): array
{
    $store = AccountStoreFactory::create(ACCOUNTSFILENAME);
    $workspaceMeta = hierarchy_workspace_meta_store()->all();
    $profiles = [];
    $businesses = [];
    $adAccounts = [];
    foreach ($store->deserialize() as $account) {
        $snapshot = hierarchy_profile_snapshot($account->name, $workspaceMeta);
        $profiles[] = $snapshot['profile'];
        array_push($businesses, ...$snapshot['businesses']);
        array_push($adAccounts, ...$snapshot['ad_accounts']);
    }
    return ['profiles' => $profiles, 'businesses' => $businesses, 'ad_accounts' => $adAccounts];
}

function decode_profile_list($value): array
{
    if (is_array($value)) $raw = $value;
    else {
        $decoded = json_decode((string)$value, true);
        $raw = is_array($decoded) ? $decoded : preg_split('/[\r\n,]+/', (string)$value);
    }
    return array_values(array_unique(array_filter(array_map(static fn($v) => trim((string)$v), $raw ?: []), static fn($v) => $v !== '')));
}

try {
    $input = MetaEndpoint::input();
    $action = strtolower(trim((string)($input['action'] ?? 'inventory')));

    if ($action === 'inventory') {
        MetaEndpoint::ok(hierarchy_inventory());
    }

    if ($action === 'sync_profile') {
        $profile = trim((string)($input['profile'] ?? ''));
        if ($profile === '') throw new InvalidArgumentException('profile is required');
        $preflight = MetaEndpoint::cachedPreflight($profile, true);
        $businesses = MetaEndpoint::cachedAsset($profile, 'businesses', '', true);
        foreach (($businesses['data'] ?? []) as $business) {
            if (!is_array($business)) continue;
            $businessId = trim((string)($business['id'] ?? ''));
            if ($businessId !== '') MetaEndpoint::cachedAsset($profile, 'business_ad_accounts', $businessId, true);
        }
        hierarchy_activity(['action'=>'sync_profile','entity_type'=>'profile','entity_id'=>$profile,'profile_name'=>$profile,'summary'=>'Дополнительная синхронизация FB-профиля завершена']);
        MetaEndpoint::ok(hierarchy_profile_snapshot($profile));
    }

    if ($action === 'sync_business') {
        $profile = trim((string)($input['profile'] ?? ''));
        $businessId = trim((string)($input['business_id'] ?? ''));
        if ($profile === '' || $businessId === '') throw new InvalidArgumentException('profile and business_id are required');
        MetaEndpoint::cachedAsset($profile, 'business_ad_accounts', $businessId, true);
        hierarchy_activity(['action'=>'sync_business','entity_type'=>'business','entity_id'=>$businessId,'profile_name'=>$profile,'business_id'=>$businessId,'summary'=>'Дополнительная синхронизация Business Manager завершена']);
        MetaEndpoint::ok(hierarchy_profile_snapshot($profile));
    }

    if ($action === 'create_business') {
        $profile = trim((string)($input['profile'] ?? ''));
        $name = trim((string)($input['name'] ?? ''));
        $pageId = trim((string)($input['primary_page'] ?? ''));
        $vertical = trim((string)($input['vertical'] ?? 'ADVERTISING'));
        $timezoneId = (int)($input['timezone_id'] ?? 1);
        $email = trim((string)($input['email'] ?? ''));
        if ($profile === '') throw new InvalidArgumentException('profile is required');
        $preflight = MetaEndpoint::cachedPreflight($profile, false);
        if (empty($preflight['business_management_granted'])) throw new InvalidArgumentException('business_management permission is required to create a Business Manager.');
        $userId = trim((string)($preflight['identity']['id'] ?? ''));
        $service = MetaEndpoint::serviceForAccountName($profile);
        $created = $service->createBusiness($userId, $name, $pageId, $vertical, $timezoneId, $email !== '' ? $email : null);
        MetaEndpoint::invalidateAsset($profile, 'businesses', '');
        $fresh = MetaEndpoint::cachedAsset($profile, 'businesses', '', true);
        $createdId = trim((string)($created['id'] ?? ''));
        hierarchy_activity(['action'=>'create_business','entity_type'=>'business','entity_id'=>$createdId,'profile_name'=>$profile,'business_id'=>$createdId,'summary'=>'Создан Business Manager' . ($name !== '' ? ': ' . $name : ''),'details'=>['primary_page'=>$pageId,'vertical'=>$vertical,'timezone_id'=>$timezoneId]]);
        MetaEndpoint::ok(['created' => $created, 'businesses' => $fresh['data'] ?? [], 'snapshot' => hierarchy_profile_snapshot($profile)]);
    }

    if ($action === 'create_ad_account') {
        $profile = trim((string)($input['profile'] ?? ''));
        $businessId = trim((string)($input['business_id'] ?? ''));
        $name = trim((string)($input['name'] ?? ''));
        $currency = trim((string)($input['currency'] ?? 'USD'));
        $timezoneId = (int)($input['timezone_id'] ?? 1);
        $fundingId = trim((string)($input['funding_id'] ?? ''));
        if ($profile === '' || $businessId === '') throw new InvalidArgumentException('profile and business_id are required');
        $preflight = MetaEndpoint::cachedPreflight($profile, false);
        if (empty($preflight['business_management_granted']) || empty($preflight['ads_management_granted'])) {
            throw new InvalidArgumentException('business_management and ads_management permissions are required to create an ad account.');
        }
        $service = MetaEndpoint::serviceForAccountName($profile);
        $created = $service->createBusinessAdAccount($businessId, $name, $currency, $timezoneId, $fundingId !== '' ? $fundingId : null);
        MetaEndpoint::invalidateAsset($profile, 'business_ad_accounts', $businessId);
        MetaEndpoint::invalidatePreflight($profile);
        MetaEndpoint::cachedPreflight($profile, true);
        MetaEndpoint::cachedAsset($profile, 'business_ad_accounts', $businessId, true);
        $createdId = trim((string)($created['id'] ?? ''));
        hierarchy_activity(['action'=>'create_ad_account','entity_type'=>'ad_account','entity_id'=>$createdId,'profile_name'=>$profile,'business_id'=>$businessId,'account_id'=>$createdId,'summary'=>'Создан рекламный кабинет' . ($name !== '' ? ': ' . $name : ''),'details'=>['currency'=>$currency,'timezone_id'=>$timezoneId,'funding_requested'=>$fundingId !== '']]);
        MetaEndpoint::ok(['created' => $created, 'snapshot' => hierarchy_profile_snapshot($profile)]);
    }

    if ($action === 'update_profile') {
        $profile = trim((string)($input['profile'] ?? ''));
        if ($profile === '') throw new InvalidArgumentException('profile is required');
        $store = AccountStoreFactory::create(ACCOUNTSFILENAME);
        $existing = $store->getAccountByName($profile);
        if ($existing === null) throw new InvalidArgumentException('Profile not found.');
        $tokenInput = trim((string)($input['token'] ?? ''));
        $token = $tokenInput !== '' ? $tokenInput : $existing->token;
        $cookiesInput = trim((string)($input['cookies'] ?? ''));
        $cookies = $cookiesInput !== '' ? $cookiesInput : json_encode($existing->cookies, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
        $clearProxy = filter_var($input['clear_proxy'] ?? false, FILTER_VALIDATE_BOOLEAN);
        $proxyInput = trim((string)($input['proxy'] ?? ''));
        $proxy = $clearProxy ? null : ($proxyInput !== '' ? RemaskProxy::fromSemicolonString($proxyInput) : $existing->proxy);
        $replacement = new FbAccount($profile, $token, $cookies, $cookiesInput !== '' ? null : $existing->dtsg, $proxy);
        $store->addOrUpdateAccount($replacement);
        if ($clearProxy || $proxyInput !== '') hierarchy_workspace_meta_store()->setProxyHealth($profile, []);
        MetaEndpoint::invalidateProfileCache($profile);
        hierarchy_activity(['action'=>'update_profile','entity_type'=>'profile','entity_id'=>$profile,'profile_name'=>$profile,'summary'=>'Обновлены настройки FB-профиля','details'=>['token_changed'=>$tokenInput !== '','cookies_changed'=>$cookiesInput !== '','proxy_changed'=>$clearProxy || $proxyInput !== '']]);
        MetaEndpoint::ok(['updated' => true, 'inventory' => hierarchy_inventory()]);
    }

    if ($action === 'assign_proxy') {
        $profiles = decode_profile_list($input['profiles'] ?? []);
        if ($profiles === []) throw new InvalidArgumentException('Select at least one Facebook profile.');
        $proxyText = trim((string)($input['proxy'] ?? ''));
        $sourceProfile = trim((string)($input['source_profile'] ?? ''));
        $clear = filter_var($input['clear'] ?? false, FILTER_VALIDATE_BOOLEAN);
        $store = AccountStoreFactory::create(ACCOUNTSFILENAME);
        if ($clear) {
            $proxy = null;
        } elseif ($sourceProfile !== '') {
            $source = $store->getAccountByName($sourceProfile);
            if ($source === null || $source->proxy === null) throw new InvalidArgumentException('Selected existing proxy is no longer available.');
            $proxy = $source->proxy;
        } else {
            if ($proxyText === '') throw new InvalidArgumentException('Enter a proxy, select an existing proxy, or choose clear.');
            $proxy = RemaskProxy::fromSemicolonString($proxyText);
        }
        $updated = [];
        foreach ($profiles as $profile) {
            $account = $store->getAccountByName($profile);
            if ($account === null) {
                $updated[] = ['profile' => $profile, 'ok' => false, 'error' => 'Profile not found'];
                continue;
            }
            $replacement = new FbAccount(
                $account->name,
                $account->token,
                json_encode($account->cookies, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                $account->dtsg,
                $proxy
            );
            $store->addOrUpdateAccount($replacement);
            hierarchy_workspace_meta_store()->setProxyHealth($profile, []);
            MetaEndpoint::invalidateProfileCache($profile);
            $updated[] = ['profile' => $profile, 'ok' => true, 'proxy_configured' => $proxy !== null];
        }
        hierarchy_activity(['action'=>'assign_proxy','entity_type'=>'profile','summary'=>($clear?'Proxy удалён у ':'Proxy назначен для ') . count($profiles) . ' FB-профилей','details'=>['profiles'=>count($profiles),'mode'=>$clear?'clear':($sourceProfile!==''?'reuse':'new')]]);
        MetaEndpoint::ok(['updated' => $updated, 'inventory' => hierarchy_inventory()]);
    }

    if ($action === 'check_proxy') {
        $profile = trim((string)($input['profile'] ?? ''));
        if ($profile === '') throw new InvalidArgumentException('profile is required');
        $store = AccountStoreFactory::create(ACCOUNTSFILENAME);
        $account = $store->getAccountByName($profile);
        if ($account === null) throw new InvalidArgumentException('Profile not found.');
        if ($account->proxy === null) throw new InvalidArgumentException('Proxy is not configured for this profile.');
        $service = new ProxyHealthService(REMASK_PROXY_CHECK_URL, REMASK_PROXY_GEO_URL, REMASK_PROXY_CHECK_TIMEOUT);
        $health = $service->check($account->proxy);
        hierarchy_workspace_meta_store()->setProxyHealth($profile, $health);
        hierarchy_activity([
            'action'=>'check_proxy',
            'entity_type'=>'profile',
            'entity_id'=>$profile,
            'profile_name'=>$profile,
            'status'=>($health['status'] ?? '') === 'LIVE' ? 'SUCCESS' : 'ERROR',
            'summary'=>'Proxy ' . ($health['status'] ?? 'UNKNOWN') . ' для ' . $profile,
            'details'=>[
                'proxy_status'=>$health['status'] ?? 'UNKNOWN',
                'exit_ip'=>$health['exit_ip'] ?? '',
                'country_code'=>$health['country_code'] ?? '',
                'latency_ms'=>$health['latency_ms'] ?? null,
            ],
        ]);
        MetaEndpoint::ok(['profile'=>$profile,'health'=>$health,'snapshot'=>hierarchy_profile_snapshot($profile)]);
    }

    if ($action === 'set_group') {
        $profiles = decode_profile_list($input['profiles'] ?? []);
        if ($profiles === []) throw new InvalidArgumentException('Select at least one Facebook profile.');
        $group = trim((string)($input['group'] ?? ''));
        $known = [];
        foreach (AccountStoreFactory::create(ACCOUNTSFILENAME)->deserialize() as $account) $known[$account->name] = true;
        foreach ($profiles as $profile) {
            if (!isset($known[$profile])) throw new InvalidArgumentException("Profile not found: {$profile}");
        }
        hierarchy_workspace_meta_store()->setGroup($profiles, $group);
        hierarchy_activity(['action'=>'set_group','entity_type'=>'profile','summary'=>'Изменена группа у ' . count($profiles) . ' FB-профилей','details'=>['profiles'=>count($profiles),'group'=>$group]]);
        MetaEndpoint::ok(['updated' => count($profiles), 'inventory' => hierarchy_inventory()]);
    }

    if ($action === 'funding_status') {
        $profile = trim((string)($input['profile'] ?? ''));
        $accountId = trim((string)($input['account_id'] ?? ''));
        if ($profile === '' || $accountId === '') throw new InvalidArgumentException('profile and account_id are required');
        $funding = MetaEndpoint::cachedAsset($profile, 'funding', $accountId, filter_var($input['force'] ?? false, FILTER_VALIDATE_BOOLEAN));
        hierarchy_activity(['action'=>'funding_sync','entity_type'=>'ad_account','entity_id'=>$accountId,'profile_name'=>$profile,'account_id'=>$accountId,'summary'=>'Обновлён Funding status рекламного кабинета']);
        MetaEndpoint::ok(['profile' => $profile, 'account_id' => $accountId, 'funding' => $funding]);
    }

    if ($action === 'set_delivery_status') {
        $profile = trim((string)($input['profile'] ?? ''));
        $entityType = strtolower(trim((string)($input['entity_type'] ?? '')));
        $entityId = trim((string)($input['entity_id'] ?? ''));
        $accountId = trim((string)($input['account_id'] ?? ''));
        $status = strtoupper(trim((string)($input['status'] ?? '')));
        if ($profile === '' || $entityId === '') throw new InvalidArgumentException('profile and entity_id are required');
        if (!in_array($entityType, ['campaigns', 'adsets', 'ads'], true)) throw new InvalidArgumentException('entity_type must be campaigns, adsets or ads');
        if (!in_array($status, ['ACTIVE', 'PAUSED'], true)) throw new InvalidArgumentException('status must be ACTIVE or PAUSED');
        $service = MetaEndpoint::serviceForAccountName($profile);
        $result = match ($entityType) {
            'campaigns' => $service->updateCampaign($entityId, ['status' => $status]),
            'adsets' => $service->updateAdSet($entityId, ['status' => $status]),
            'ads' => $service->updateAd($entityId, ['status' => $status]),
        };
        if ($accountId !== '') MetaEndpoint::invalidateAsset($profile, $entityType, $accountId);
        hierarchy_activity(['action'=>'set_delivery_status','entity_type'=>rtrim($entityType,'s'),'entity_id'=>$entityId,'profile_name'=>$profile,'account_id'=>$accountId,'summary'=>strtoupper($entityType) . ' ' . $entityId . ' → ' . $status,'details'=>['status'=>$status]]);
        MetaEndpoint::ok([
            'profile' => $profile,
            'entity_type' => $entityType,
            'entity_id' => $entityId,
            'status' => $status,
            'result' => $result,
        ]);
    }

    throw new InvalidArgumentException('Unsupported hierarchy action.');
} catch (Throwable $error) {
    $safeAction = isset($action) ? (string)$action : 'unknown';
    if ($safeAction !== 'inventory') {
        hierarchy_activity([
            'action' => $safeAction,
            'entity_type' => '',
            'entity_id' => trim((string)($input['entity_id'] ?? '')),
            'profile_name' => trim((string)($input['profile'] ?? '')),
            'business_id' => trim((string)($input['business_id'] ?? '')),
            'account_id' => trim((string)($input['account_id'] ?? '')),
            'status' => 'ERROR',
            'summary' => substr($error->getMessage(), 0, 500),
        ]);
    }
    MetaEndpoint::fail($error);
}
